img = imread('../src/office.jpg');
imshow(demo(img, 2, 0.25, 1, 2000))